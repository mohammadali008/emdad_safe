from django.contrib import admin
from .models import Ticket

@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display = ('user', 'service', 'status', 'is_active', 'created_at')
    list_filter = ('status', 'is_active')
    search_fields = ('user__phone_number', 'service__title', 'description')
